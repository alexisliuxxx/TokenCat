create trigger phone_user_integral
  after INSERT
  on phone_user
  for each row
BEGIN
DECLARE uid BIGINT(20);
SET uid = NEW.id;
INSERT INTO activity_info(phone_user_id,activity_type,`status`) values(uid,1,1);
END;

