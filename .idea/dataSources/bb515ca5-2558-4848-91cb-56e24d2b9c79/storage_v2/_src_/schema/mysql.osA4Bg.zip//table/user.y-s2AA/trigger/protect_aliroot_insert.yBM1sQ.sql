create trigger protect_aliroot_insert
  before INSERT
  on user
  for each row
begin

select user() into @current_user_host;
select reverse(substring_index(reverse(@current_user_host), '@', -1)) into @current_user;

select @@global.maintain_user_list into @maintain_list;
set @cnt= 1 + LENGTH(@maintain_list) - LENGTH(REPLACE(@maintain_list, ',', ''));
SET @i=1 ;
SET @allowed=0;
SET @modify_maintain=0;
WHILE @i <= @cnt DO
  SET @result = REVERSE(SUBSTRING_INDEX(REVERSE(SUBSTRING_INDEX(@maintain_list,',',@i)),',',1));
  SET @i= @i + 1;
  if @result=@current_user then
    SET @allowed=1;
  end if;
  if @result=new.user then
    SET @modify_maintain=1;
  end if;
end while;

if ('Y' = new.Shutdown_priv
        or 'Y' = new.Show_db_priv
    or 'Y' = new.Super_priv
    or 'Y' = new.Create_tablespace_priv
    or 'Y' = new.File_priv) then
  SET @modify_maintain=1;
end if;

if @allowed=0 and @modify_maintain=1 then
  signal sqlstate '45002' set message_text = 'can not insert reserved users or privileges';
end if;

end;

