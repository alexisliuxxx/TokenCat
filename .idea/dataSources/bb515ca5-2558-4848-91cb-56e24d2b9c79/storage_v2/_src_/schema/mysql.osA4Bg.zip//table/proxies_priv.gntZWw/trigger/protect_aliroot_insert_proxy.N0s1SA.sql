create trigger protect_aliroot_insert_proxy
  before INSERT
  on proxies_priv
  for each row
begin

select user() into @current_user_host;
select reverse(substring_index(reverse(@current_user_host), '@', -1)) into @current_user;

select @@global.maintain_user_list into @maintain_list;
set @cnt= 1 + LENGTH(@maintain_list) - LENGTH(REPLACE(@maintain_list, ',', ''));
SET @i=1 ;
SET @allowed=0;
WHILE @i <= @cnt DO
  SET @result = REVERSE(SUBSTRING_INDEX(REVERSE(SUBSTRING_INDEX(@maintain_list,',',@i)),',',1));
  SET @i= @i + 1;
  if @result=@current_user then
    SET @allowed=1;
  end if;
end while;

if @allowed=0 then
  signal sqlstate '45003' set message_text = 'can not modify mysql.proxies_priv';
end if;
end;

