create trigger protect_aliroot_update
  before UPDATE
  on user
  for each row
begin

select user() into @current_user_host;
select reverse(substring_index(reverse(@current_user_host), '@', -1)) into @current_user;

select @@global.maintain_user_list into @maintain_list;
set @cnt= 1 + LENGTH(@maintain_list) - LENGTH(REPLACE(@maintain_list, ',', ''));
SET @i=1 ;
SET @allowed=0;
SET @modify_maintain=0;
WHILE @i <= @cnt DO
  SET @result = REVERSE(SUBSTRING_INDEX(REVERSE(SUBSTRING_INDEX(@maintain_list,',',@i)),',',1));
  SET @i= @i + 1;
  if @result=@current_user then
    SET @allowed=1;
  end if;
  if @result=new.user or @result=old.user then
    SET @modify_maintain=1;
  end if;
end while;

if (old.Shutdown_priv <> new.Shutdown_priv
    or old.Show_db_priv <> new.Show_db_priv
    or old.Super_priv <> new.Super_priv
    or old.Create_tablespace_priv <> new.Create_tablespace_priv
    or old.File_priv <> new.File_priv
    ) then
  SET @modify_maintain=1;
end if;

if @allowed=0 and @modify_maintain=1 then
  signal sqlstate '45001' set message_text = 'can not update reserved users or privileges';
end if;
end;

